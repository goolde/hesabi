from datetime import date
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from sqlmodel import Session, select
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.middleware import SlowAPIMiddleware
from .config import settings
from .database import create_db_and_tables, get_session
from .models import User, RegisterIn, Token, Contact, ContactIn, Transaction, TransactionIn
from .security import hash_password, verify_password, create_access_token, get_current_user

limiter = Limiter(key_func=get_remote_address)
app = FastAPI(title=settings.app_name)
app.state.limiter = limiter
app.add_middleware(SlowAPIMiddleware)

origins = [x.strip() for x in settings.cors_origins.split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
)

@app.on_event("startup")
def on_startup():
    create_db_and_tables()

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/auth/register", response_model=Token)
@limiter.limit("5/minute")
def register(request: Request, data: RegisterIn, session: Session = Depends(get_session)):
    if len(data.password) < 8:
        raise HTTPException(status_code=400, detail="كلمة المرور لازم تكون 8 أحرف على الأقل")
    existing = session.exec(select(User).where(User.phone == data.phone)).first()
    if existing:
        raise HTTPException(status_code=400, detail="رقم الجوال مسجل مسبقاً")
    user = User(full_name=data.full_name, phone=data.phone, email=data.email, password_hash=hash_password(data.password))
    session.add(user)
    session.commit()
    token = create_access_token(data.phone)
    return Token(access_token=token)

@app.post("/auth/login", response_model=Token)
@limiter.limit("10/minute")
def login(request: Request, form: OAuth2PasswordRequestForm = Depends(), session: Session = Depends(get_session)):
    # username = phone
    user = session.exec(select(User).where(User.phone == form.username)).first()
    if not user or not verify_password(form.password, user.password_hash):
        raise HTTPException(status_code=401, detail="رقم الجوال أو كلمة المرور غير صحيحة")
    return Token(access_token=create_access_token(user.phone))

@app.get("/me")
def me(user: User = Depends(get_current_user)):
    return {"id": user.id, "full_name": user.full_name, "phone": user.phone, "email": user.email}

@app.post("/contacts", response_model=Contact)
def create_contact(data: ContactIn, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    contact = Contact(owner_id=user.id, **data.model_dump())
    session.add(contact)
    session.commit()
    session.refresh(contact)
    return contact

@app.get("/contacts")
def list_contacts(user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    return session.exec(select(Contact).where(Contact.owner_id == user.id).order_by(Contact.created_at.desc())).all()

@app.delete("/contacts/{contact_id}")
def delete_contact(contact_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    contact = session.get(Contact, contact_id)
    if not contact or contact.owner_id != user.id:
        raise HTTPException(status_code=404, detail="غير موجود")
    session.delete(contact)
    session.commit()
    return {"deleted": True}

@app.post("/transactions", response_model=Transaction)
def create_transaction(data: TransactionIn, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    payload = data.model_dump()
    if payload.get("tx_date") is None:
        payload["tx_date"] = date.today()
    tx = Transaction(owner_id=user.id, **payload)
    session.add(tx)
    session.commit()
    session.refresh(tx)
    return tx

@app.get("/transactions")
def list_transactions(user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    return session.exec(select(Transaction).where(Transaction.owner_id == user.id).order_by(Transaction.created_at.desc())).all()

@app.put("/transactions/{tx_id}", response_model=Transaction)
def update_transaction(tx_id: int, data: TransactionIn, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    tx = session.get(Transaction, tx_id)
    if not tx or tx.owner_id != user.id:
        raise HTTPException(status_code=404, detail="غير موجود")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(tx, key, value)
    session.add(tx)
    session.commit()
    session.refresh(tx)
    return tx

@app.delete("/transactions/{tx_id}")
def delete_transaction(tx_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    tx = session.get(Transaction, tx_id)
    if not tx or tx.owner_id != user.id:
        raise HTTPException(status_code=404, detail="غير موجود")
    session.delete(tx)
    session.commit()
    return {"deleted": True}

@app.get("/dashboard")
def dashboard(user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    txs = session.exec(select(Transaction).where(Transaction.owner_id == user.id)).all()
    incoming = sum(t.amount for t in txs if t.tx_type == "incoming" and t.status != "settled")
    outgoing = sum(t.amount for t in txs if t.tx_type == "outgoing" and t.status != "settled")
    settled = len([t for t in txs if t.status == "settled"])
    contacts_count = len(session.exec(select(Contact).where(Contact.owner_id == user.id)).all())
    return {
        "total_for_me": incoming,
        "total_on_me": outgoing,
        "net_balance": incoming - outgoing,
        "transactions_count": len(txs),
        "contacts_count": contacts_count,
        "settled_count": settled,
    }
